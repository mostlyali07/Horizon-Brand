<div class="testimonial">
<div class="container py-3 testimonial">
    <div class="row">
        <div class="col-md-12">
            <h2 class="text-clrr text-center py-4">
                OUR TOP
                RECOMMENDATION FOR REACHING MORE
                TARGETED AUDIENCES WITH ADDITIONAL
                BOOK MARKETING SERVICES
            </h2>
            <div class="owl-seven owl-carousel owl-theme">
                <div class="item testi">
                    <img src="./img/google-business.png" class="widr">
                    <h5 class="testi-slid">Google Business</h5>
                </div>
                <div class="item testi">
                    <img src="./img/yelp.png" class="widr">
                    <h5 class="testi-slid">Yelp</h5>
                </div>
                <div class="item testi">
                    <img src="./img/youTube-promotion.png" class="widr">
                    <h5 class="testi-slid">YouTube Promotion</h5>
                </div>
                <div class="item testi">
                    <img src="./img/amazon-QR-code.png" class="widr">
                    <h5 class="testi-slid">Amazon QR Code</h5>
                </div>
                <div class="item testi">
                    <img src="./img/tiktok.png" class="widr">
                    <h5 class="testi-slid">Tik-Tok</h5>
                </div>
                <div class="item testi">
                    <img src="./img/website-seo.png" class="widr">
                    <h5 class="testi-slid">Website SEO</h5>
                </div>
                <div class="item testi">
                    <img src="./img/website-ppc.png" class="widr">
                    <h5 class="testi-slid">Website PPC</h5>
                </div>
                <div class="item testi">
                    <img src="./img/paid-social-media-marketing.png" class="widr">
                    <h5 class="testi-slid">Paid Social Media Marketing</h5>
                </div>
                <div class="item testi">
                    <img src="./img/amazon-best-seller-marketing.jpg" class="widr">
                    <h5 class="testi-slid">Amazon Best Seller Marketing</h5>
                </div>
            </div>
        </div>
    </div>
</div>
</div>