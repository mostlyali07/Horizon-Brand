<div class="main-bannerr">
        <div class="container">
            <div class="row">
                <div class="col-md-12 banner-left d-flex align-items-center text-center">
                    <div>
                        <h1> 
                            <span style="color: #f58b01;"> BOOK PROMOTION</span> TO REACH THE  
                            <span style="color: #f58b01;">HORIZON</span><br>  WITH OUR BOOK<span style="color: #f58b01;"> MARKETING SERVICES.</span>
                        </h1>
                        <p>
                            Successful book marketing takes time, effort, and dedication. By utilizing a variety of marketing strategies and consistent effort, we can increase your book's visibility and reach the horizon of success.
                        </p>
                        <button class="btns-one" type="submit"><i class="fa-solid fa-cube"></i>&nbsp; Call Us
                            Now</button>&nbsp;&nbsp;
                        <button class="btns-two" type="submit"><i class="fa-solid fa-file-signature"></i>&nbsp;
                            Chat Now</button>
                    </div>
                </div>
            </div>
        </div>
    </div>